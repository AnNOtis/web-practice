var SERVER_PATH="http://203.64.139.10:8080/iTS5/";
// var SERVER_PATH="http://203.69.207.173:8080/iTS5/";
var SCHOOL_NAME="cmgsh";
// var SCHOOL_NAME="SCE";